let database = {};

module.exports = database;